declare module '*.vue' {
  import { ComponentOptions } from 'vue'

  const comp: ComponentOptions
  export default comp
}
