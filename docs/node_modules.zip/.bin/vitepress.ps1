#!/usr/bin/env pwsh
$basedir=Split-Path $MyInvocation.MyCommand.Definition -Parent

$exe=""
$pathsep=":"
$env_node_path=$env:NODE_PATH
$new_node_path="D:\web\业余代码\ayu\node_modules\.pnpm\vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0\node_modules\vitepress\bin\node_modules;D:\web\业余代码\ayu\node_modules\.pnpm\vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0\node_modules\vitepress\node_modules;D:\web\业余代码\ayu\node_modules\.pnpm\vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0\node_modules;D:\web\业余代码\ayu\node_modules\.pnpm\node_modules"
if ($PSVersionTable.PSVersion -lt "6.0" -or $IsWindows) {
  # Fix case when both the Windows and Linux builds of Node
  # are installed in the same directory
  $exe=".exe"
  $pathsep=";"
} else {
  $new_node_path="/mnt/d/web/业余代码/ayu/node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/bin/node_modules:/mnt/d/web/业余代码/ayu/node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/node_modules:/mnt/d/web/业余代码/ayu/node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules:/mnt/d/web/业余代码/ayu/node_modules/.pnpm/node_modules"
}
if ([string]::IsNullOrEmpty($env_node_path)) {
  $env:NODE_PATH=$new_node_path
} else {
  $env:NODE_PATH="$new_node_path$pathsep$env_node_path"
}

$ret=0
if (Test-Path "$basedir/node$exe") {
  # Support pipeline input
  if ($MyInvocation.ExpectingInput) {
    $input | & "$basedir/node$exe"  "$basedir/../../../node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/bin/vitepress.js" $args
  } else {
    & "$basedir/node$exe"  "$basedir/../../../node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/bin/vitepress.js" $args
  }
  $ret=$LASTEXITCODE
} else {
  # Support pipeline input
  if ($MyInvocation.ExpectingInput) {
    $input | & "node$exe"  "$basedir/../../../node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/bin/vitepress.js" $args
  } else {
    & "node$exe"  "$basedir/../../../node_modules/.pnpm/vitepress@1.2.0_@algolia+client-search@4.23.3_search-insights@2.13.0/node_modules/vitepress/bin/vitepress.js" $args
  }
  $ret=$LASTEXITCODE
}
$env:NODE_PATH=$env_node_path
exit $ret
